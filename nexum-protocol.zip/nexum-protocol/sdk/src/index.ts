/**
 * NEXUM Protocol SDK v0.1.0
 * Embed NEXUM reputation and task primitives in any Solana dApp
 * @license MIT
 */

export * from './tasks';
export * from './reputation';

export const NEXUM_PROGRAM_ID = 'NXMxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
export const NEXUM_VERSION    = '0.1.0';
