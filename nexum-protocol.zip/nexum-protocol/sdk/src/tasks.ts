import { PublicKey, Connection, Transaction } from '@solana/web3.js';

export interface Task {
  id: string;
  title: string;
  reward: number;
  currency: 'SOL' | 'NXM';
  deadline: Date;
  status: 'open' | 'in_progress' | 'submitted' | 'completed' | 'disputed';
  poster: PublicKey;
  contributor?: PublicKey;
}

export async function fetchOpenTasks(connection: Connection): Promise<Task[]> {
  // TODO: PDA account fetch — v0.1.0
  return [];
}

export async function createTask(
  connection: Connection,
  poster: PublicKey,
  task: Omit<Task, 'id' | 'status' | 'poster'>
): Promise<Transaction> {
  throw new Error('Coming in v0.1.0');
}
