import { PublicKey, Connection } from '@solana/web3.js';

export interface ReputationScore {
  wallet: PublicKey;
  score: number;
  tasksCompleted: number;
  memberSince: Date;
}

export async function getReputation(
  connection: Connection,
  wallet: PublicKey
): Promise<ReputationScore | null> {
  // TODO: SBT account query — v0.1.0
  return null;
}
